# 🎥 Como Adicionar Vídeos do YouTube

## Passo a Passo Completo

### 1️⃣ Encontrar o ID do Vídeo

Cada vídeo do YouTube tem um ID único. Para encontrá-lo:

**Opção A: Na URL da página**
```
https://www.youtube.com/watch?v=AQUI_ESTA_O_ID
```

**Opção B: URL curta**
```
https://youtu.be/AQUI_ESTA_O_ID
```

O ID é sempre uma sequência de 11 caracteres.

**Exemplo:**
- URL completa: `https://www.youtube.com/watch?v=dQw4w9WgXcQ`
- ID: `dQw4w9WgXcQ`

### 2️⃣ Editar o arquivo index.html

Procure pela seção "Seção Vídeos YouTube" no arquivo `index.html`.

Você verá blocos assim:

```html
<!-- Vídeo 1 -->
<div class="video-item">
    <div class="video-wrapper">
        <iframe 
            src="https://www.youtube.com/embed/ADICIONE_VIDEO_ID_1"
            ...
        ></iframe>
    </div>
    <h3>Título do Vídeo 1</h3>
    <p>Descrição breve do conteúdo do vídeo 1</p>
</div>
```

### 3️⃣ Substituir os Dados

Substitua:

1. **O ID do vídeo:**
   ```html
   <!-- Antes -->
   src="https://www.youtube.com/embed/ADICIONE_VIDEO_ID_1"

   <!-- Depois -->
   src="https://www.youtube.com/embed/dQw4w9WgXcQ"
   ```

2. **O título:**
   ```html
   <!-- Antes -->
   <h3>Título do Vídeo 1</h3>

   <!-- Depois -->
   <h3>Libras Básico - Aula Introdutória</h3>
   ```

3. **A descrição:**
   ```html
   <!-- Antes -->
   <p>Descrição breve do conteúdo do vídeo 1</p>

   <!-- Depois -->
   <p>Aprenda os conceitos básicos da Língua de Sinais com exemplos práticos</p>
   ```

## 📚 Exemplos de Vídeos Recomendados

Se você não tem vídeos próprios, pode procurar por:

- Vídeos sobre Libras no YouTube
- Tutoriais de interpretação
- Conteúdos educativos sobre acessibilidade
- Sua própria demonstração de trabalho

## ✅ Checklist Final

Após adicionar os vídeos:

- [ ] Todos os 6 vídeos foram adicionados (ou menos se preferir)
- [ ] Os IDs estão corretos
- [ ] Os títulos descrevem o conteúdo
- [ ] As descrições são relevantes
- [ ] Os vídeos carregam corretamente quando você abre o site

## 🎬 Estrutura Completa com Vídeos

```html
<section id="videos" class="section videos">
    <div class="container">
        <h2 class="section-title">Vídeos & Conteúdos</h2>
        <p class="section-intro">Assista aos conteúdos...</p>

        <div class="videos-grid">
            <!-- Vídeo 1 -->
            <div class="video-item">
                <div class="video-wrapper">
                    <iframe 
                        src="https://www.youtube.com/embed/VIDEO_ID_AQUI"
                        ...
                    ></iframe>
                </div>
                <h3>Seu Título Aqui</h3>
                <p>Sua descrição aqui</p>
            </div>

            <!-- Repita para vídeos 2-6 -->
        </div>
    </div>
</section>
```

## 🆘 Dicas de Troubleshooting

**Vídeo não aparece?**
- Verifique se o ID está correto
- Certifique-se de usar `https://www.youtube.com/embed/` (não a URL comum)
- Verifique se o vídeo não é privado

**Vídeo aparece mas é lento?**
- Isso é normal se sua internet é lenta
- O site tem lazy loading para otimizar o carregamento

**Quer remover um vídeo?**
- Simplesmente delete o bloco `<div class="video-item">...</div>` todo

---

**Dica Pro:** Você pode ter de 1 a 6 vídeos. Se quiser mais, duplique o bloco de um vídeo e incremente os números!
