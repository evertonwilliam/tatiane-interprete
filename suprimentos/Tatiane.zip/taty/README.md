# Tatiane Leão - Intérprete de Libras

## 📋 Descrição

Site profissional landing page para Tatiane Leão, especializada em interpretação e educação em Libras (Língua Brasileira de Sinais). O site foi desenvolvido com foco em **acessibilidade**, **responsividade** e **inclusão**.

## ✨ Características Principais

### 🎨 Design Moderno
- Cores inspiradas em Libras (azul, branco, tons pastéis)
- Interface intuitiva e moderna
- Animações suaves e transições fluidas
- Design responsivo (mobile-first)

### ♿ Acessibilidade
- **Modo Escuro/Claro**: Toggle entre temas para conforto visual
- **Preparado para Leitores de Tela**: HTML semântico com ARIA labels
- **Navegação Intuitiva**: Menu fixo e smooth scroll
- **Contraste Adequado**: Cores com contraste conforme WCAG
- **Fontes Legíveis**: Fonte Poppins, tamanhos generosos

### 📱 Responsividade
- Totalmente responsivo para:
  - Celulares (320px+)
  - Tablets (768px+)
  - Desktops (1024px+)
  - Notebooks (1200px+)

### 🚀 Performance
- Carregamento rápido
- Imagens otimizadas
- CSS e JavaScript minificado
- Estrutura leve

## 📁 Estrutura do Projeto

```
tatiane-leao-site/
├── index.html           # Arquivo principal HTML
├── css/
│   └── styles.css       # Estilos CSS (completo)
├── js/
│   └── script.js        # Lógica JavaScript
├── imagens/             # Pasta para armazenar imagens
│   ├── tatiane-leao-hero.jpg
│   ├── portfolio-evento.jpg
│   ├── portfolio-educacao.jpg
│   ├── portfolio-saude.jpg
│   ├── portfolio-treinamento.jpg
│   ├── portfolio-inclusao.jpg
│   └── portfolio-consultoria.jpg
└── README.md           # Este arquivo
```

## 🎯 Seções do Site

1. **Header Fixo**: Menu de navegação sempre visível com links para cada seção
2. **Hero Section**: Apresentação principal com foto e CTA
3. **Experiência**: Dados profissionais, empresa e especialidades
4. **Portfólio**: Galeria de trabalhos e atuações
5. **Sobre**: Descrição completa da profissional
6. **Serviços**: Detalhamento dos serviços oferecidos
7. **Contato**: Formulário, informações e redes sociais
8. **Footer**: Rodapé com links e copyright

## 🛠️ Como Usar

### Instalação
1. Extraia a pasta `tatiane-leao-site`
2. Não há dependências externas - funciona localmente!
3. Abra `index.html` em seu navegador

### Customização

#### Adicionar Imagens
1. Coloque as imagens na pasta `imagens/`
2. Atualize os `src` no HTML:
```html
<img src="imagens/sua-imagem.jpg" alt="Descrição">
```

#### Atualizar Informações
1. Edite as informações de contato em:
   - Links WhatsApp: `5517985853652`
   - Email: `tatiane.leao@gmail.com`
   - Instagram: `@tatiane.leao.75`
   - Facebook: `@tatiane.leao.75`

#### Configurar Tema de Cores
Edite as variáveis CSS em `css/styles.css`:
```css
:root {
    --primary-color: #0066cc;      /* Cor primária */
    --accent-color: #00b8e6;       /* Cor de destaque */
    /* ... outras cores */
}
```

## 🌐 Deploy (Publicar Online)

### Opção 1: GitHub Pages
1. Crie uma conta em GitHub
2. Crie um novo repositório público
3. Faça upload dos arquivos
4. Ative GitHub Pages nas configurações

### Opção 2: Netlify
1. Acesse netlify.com
2. Faça drag & drop da pasta do projeto
3. Site será publicado automaticamente

### Opção 3: Servidor Web
1. Contrate hospedagem
2. Use FTP para upload dos arquivos
3. Configure DNS (domínio)

## 🎨 Recursos de Acessibilidade Implementados

✅ Modo escuro/claro (preservado em localStorage)  
✅ Menu responsivo para dispositivos móveis  
✅ Navegação por teclado (Tab)  
✅ ARIA labels para elementos interativos  
✅ Contraste de cores adequado  
✅ Fontes legíveis em vários tamanhos  
✅ Botão "voltar ao topo" para facilitar navegação  
✅ Formulário acessível com campos nomeados  
✅ Smooth scroll para melhor experiência  

## 📱 Compatibilidade

- ✅ Chrome/Edge (Recomendado)
- ✅ Firefox
- ✅ Safari
- ✅ Opera
- ✅ Navegadores mobile (iOS/Android)

## 🔧 Tecnologias Utilizadas

- **HTML5**: Estrutura semântica
- **CSS3**: Design responsivo, flexbox, grid, animações
- **JavaScript Vanilla**: Sem dependências externas
- **Font Awesome**: Ícones
- **Google Fonts**: Fonte Poppins

## 📄 Licença

Este projeto foi desenvolvido especificamente para Tatiane Leão. Todos os direitos reservados.

## 💬 Suporte

Para dúvidas ou personalizações, entre em contato através das informações disponíveis no site.

---

**Desenvolvido com ❤️ para promover acessibilidade e inclusão da comunidade surda.**

Versão 1.0 - 2024
