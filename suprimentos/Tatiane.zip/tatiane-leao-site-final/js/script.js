// ===================================
// ALFA LEÃO - SCRIPTS PRINCIPAIS
// =================================== 

// 1. TEMA ESCURO/CLARO
const themeToggle = document.getElementById('theme-toggle');
const body = document.body;
const savedTheme = localStorage.getItem('theme') || 'light';

if (savedTheme === 'dark') {
    body.classList.add('dark');
    themeToggle.textContent = '🌙';
}

themeToggle.addEventListener('click', () => {
    body.classList.toggle('dark');
    const isDark = body.classList.contains('dark');
    themeToggle.textContent = isDark ? '🌙' : '☀️';
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
});

// 2. MENU MOBILE
const menuToggle = document.getElementById('menu-toggle');
const navMenu = document.getElementById('nav-menu');

menuToggle.addEventListener('click', () => {
    navMenu.classList.toggle('active');
    const isOpen = navMenu.classList.contains('active');
    menuToggle.setAttribute('aria-expanded', isOpen);
});

// Fechar menu ao clicar em um link
navMenu.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
        navMenu.classList.remove('active');
        menuToggle.setAttribute('aria-expanded', 'false');
    });
});

// 3. HEADER EFFECT
const header = document.querySelector('header');
let lastScrollTop = 0;

window.addEventListener('scroll', () => {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;

    if (scrollTop > 100) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }

    lastScrollTop = scrollTop;
});

// 4. SMOOTH SCROLL (já existe com scroll-behavior: smooth no CSS)

// 5. FORM HANDLING
const contactForm = document.getElementById('contact-form');
if (contactForm) {
    contactForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const nome = document.querySelector('input[name="nome"]').value;
        const email = document.querySelector('input[name="email"]').value;
        const empresa = document.querySelector('input[name="empresa"]').value;
        const mensagem = document.querySelector('textarea[name="mensagem"]').value;

        // Validação básica
        if (!nome || !email || !mensagem) {
            alert('Por favor, preencha os campos obrigatórios (Nome, Email, Mensagem)');
            return;
        }

        // Criar body do email
        const emailBody = `
Nome: ${nome}
Email: ${email}
Empresa: ${empresa}

Mensagem:
${mensagem}
        `.trim();

        // Redirecionar para mailto
        const mailtoLink = `mailto:tati.oliver.leao@hotmail.com?subject=Contato Alfa Leão&body=${encodeURIComponent(emailBody)}`;
        window.location.href = mailtoLink;

        // Limpar formulário
        contactForm.reset();
    });
}

// 6. ANALYTICS (opcional)
console.log('✓ Alfa Leão - Site Carregado com Sucesso');
console.log('✓ VLibras Ativado para Acessibilidade em Libras');

// 7. DETECÇÃO DE PRÉFERÊNCIA DO SISTEMA
if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches && !localStorage.getItem('theme')) {
    body.classList.add('dark');
    themeToggle.textContent = '🌙';
}

// 8. LINKS EXTERNOS
document.querySelectorAll('a[target="_blank"]').forEach(link => {
    link.setAttribute('rel', 'noopener noreferrer');
});
