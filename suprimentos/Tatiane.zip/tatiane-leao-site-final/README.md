# ALFA LEÃO - Acessibilidade em Libras

## 📋 Sobre

Alfa Leão é uma empresa especializada em acessibilidade e interpretação de Libras para empresas. Fundada por Tatiane Leão, com mais de 10 anos de experiência.

**CNPJ:** 38.056.251/0001-60

## 🎯 Seções do Site

- **Home**: Apresentação principal
- **Quem Somos**: História e informações sobre Tatiane Leão
- **Sobre Libras**: Legislação e importância estratégica
- **Serviços**: Interpretação, RH, Saúde, Apoio Corporativo
- **Treinamento**: Curso básico 40 horas com 5 módulos
- **Portfólio**: Casos de sucesso
- **Contato**: Formulário e informações

## 🎨 Design System

### Cores (Manual de Marca)
- **Primária**: #0066CC (Azul Libras)
- **Primária Dark**: #0052A3
- **Primária Light**: #E6F0FF
- **Texto**: #333333
- **Fundo**: #FFFFFF
- **Fundo Claro**: #F8F9FA

### Tipografia
- **Font**: Poppins (Google Fonts)
- **Weights**: 300, 400, 600, 700

## ✨ Funcionalidades

✅ Design responsivo (mobile-first)
✅ Tema escuro/claro com persistência
✅ Menu mobile com hamburguer
✅ VLibras integrado para acessibilidade em Libras
✅ Formulário de contato funcional
✅ Links sociais e WhatsApp
✅ Acessibilidade WCAG (ARIA labels, semântica)
✅ Animações suaves
✅ Performance otimizada

## 📱 Responsividade

- Desktop: 1200px+
- Tablet: 768px - 1199px
- Mobile: até 767px

## 🔗 Contato

- **WhatsApp**: (17) 98585-3652
- **Email**: tati.oliver.leao@hotmail.com
- **Instagram**: @tatiane.leao.75
- **Facebook**: @tatiane.leao.75

## 📄 Estrutura de Arquivos

```
tatiane-leao-site-final/
├── index.html           # HTML principal
├── css/
│   └── styles.css       # Estilos CSS completo
├── js/
│   └── script.js        # JavaScript
├── imagens/             # Pasta para imagens
│   ├── portfolio-tatiane-1.jpg
│   ├── portfolio-tatiane-2.jpg
│   └── portfolio-tatiane-3.jpg
└── docs/
    ├── MANUAL-DE-MARCA-ALFA-LEAO.pdf
    └── Libras-e-seus-servicos.pdf
```

## 🚀 Como Usar

1. Extraia o arquivo ZIP
2. Adicione as imagens profissionais de Tatiane na pasta `/imagens/`
3. Abra `index.html` no navegador
4. O VLibras carregará automaticamente

## 🔧 Customização

### Alterar Cores
Edite as variáveis CSS em `css/styles.css`:
```css
:root {
    --primary: #0066CC;
    /* ... outras cores ... */
}
```

### Alterar Informações de Contato
Edite o HTML em `index.html` e procure pelos dados de contato.

### Adicionar Imagens
Coloque as imagens profissionais de Tatiane em `/imagens/` com os nomes:
- `portfolio-tatiane-1.jpg`
- `portfolio-tatiane-2.jpg`
- `portfolio-tatiane-3.jpg`

## ♿ Acessibilidade

- Compatível com leitores de tela
- Navegação por teclado
- Contraste WCAG AA
- VLibras integrado
- ARIA labels em elementos interativos
- Modo escuro para conforto visual

## 📦 Dependências

- Google Fonts (Poppins)
- Font Awesome 6.4 (Ícones)
- VLibras (Tradução para Libras)

Todas as dependências são carregadas via CDN.

## 📄 Licença

© 2024 Alfa Leão Acessibilidade. Todos os direitos reservados.

---

Desenvolvido com ❤️ para promover acessibilidade e inclusão em Libras.
