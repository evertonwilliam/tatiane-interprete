# 📖 Guia Completo do VLibras

## O que é VLibras?

**VLibras** é uma tecnologia de **acessibilidade em Libras** desenvolvida pelo **Governo Federal Brasileiro**. Ela traduz automaticamente conteúdo de texto e fala para a Língua Brasileira de Sinais, exibindo um avatar 3D que interpreta o conteúdo em tempo real.

## Como Funciona no Site de Tatiane Leão

### 1. O Ícone de Acessibilidade
- Aparece automaticamente no **canto inferior direito** da tela
- É um ícone arredondado com a letra "V"
- Flutuante e sempre visível

### 2. Ativação do VLibras
Para usar o VLibras:
1. Clique no ícone "V" no canto da tela
2. Uma janela abrirá com o avatar
3. O avatar começará a traduzir o conteúdo para Libras

### 3. Como o Avatar Interpreta
- Quando você **navega pelo site**, o avatar traduz o conteúdo das seções
- Se houver **áudio**, o avatar sincroniza a interpretação
- O avatar aparece em uma **janela flutuante** que pode ser redimensionada

## Recursos do VLibras

✅ Tradução **automática** para Libras  
✅ Avatar **3D em tempo real**  
✅ Sincronização com conteúdo  
✅ **Gratuito** - Serviço Público  
✅ Sem necessidade de instalação  
✅ Funciona em qualquer navegador moderno  
✅ Preparado para **leitores de tela**  

## Implementação Técnica

O site carrega o VLibras através de um script:

```html
<!-- No <head> do HTML -->
<script type="text/javascript" src="https://vlibras.gov.br/app/vlibras.js"></script>
<script type="text/javascript">
    new window.VLibras.Widget('https://vlibras.gov.br/app');
</script>
```

Isso garante que:
- O widget carregue automaticamente
- Nenhuma configuração adicional é necessária
- O ícone apareça assim que a página carregar

## Posicionamento do Widget

O CSS do site foi otimizado para que o VLibras **não sobreponha** outros elementos:

```css
body .vlibras.vlibras-fixed {
    position: fixed !important;
    right: 10px !important;
    bottom: 100px !important; /* Espaço para botão scroll-to-top */
    z-index: 9998;
}
```

Isso significa:
- O VLibras fica **abaixo do botão voltar ao topo**
- Não interfere na navegação
- Permanece **sempre acessível**

## Dicas de Uso

### Para Visitantes
1. **Procure o ícone "V"** no canto da tela
2. **Clique para ativar**
3. **Personalize** o tamanho da janela (se necessário)
4. **Navegue normalmente** - o avatar acompanhará

### Para Pessoas Surdas
- O VLibras torna o site **totalmente acessível em Libras**
- Você pode ler e entender todo o conteúdo através da interpretação
- O avatar é de alta qualidade e compreensível

### Para Pessoas com Deficiência Auditiva
- O VLibras é um **complemento** aos outros modos de acessibilidade
- Combine com **legendas** e **modo escuro** para melhor experiência

## Limitações e Considerações

⚠️ **Conteúdo Dinâmico**: O VLibras interpreta melhor conteúdo **estático** (texto, títulos, descrições)

⚠️ **Vídeos Embutidos**: Para vídeos do YouTube, a melhor prática é ativar as **legendas automáticas do YouTube**

⚠️ **Conexão**: Requer **conexão com internet** para funcionar (é um serviço em nuvem)

⚠️ **Navegadores**: Funciona melhor em navegadores **modernos** (Chrome, Firefox, Safari, Edge)

## Atualizações e Suporte

O VLibras é mantido pelo **Governo Federal**. Para:
- **Bugs**: Reporte em https://vlibras.gov.br/
- **Dúvidas**: Consulte a documentação oficial
- **Melhorias**: O governo constantemente melhora a tecnologia

## Desabilitar o VLibras (se necessário)

Se por algum motivo você quiser **remover o VLibras** do site:

1. Abra `index.html`
2. Procure pelas linhas:
```html
<script type="text/javascript" src="https://vlibras.gov.br/app/vlibras.js"></script>
<script type="text/javascript">
    new window.VLibras.Widget('https://vlibras.gov.br/app');
</script>
```
3. **Delete** essas duas linhas
4. Salve o arquivo

O site continuará funcionando normalmente, só que sem o VLibras.

## Alternativas de Acessibilidade

O site também oferece:
- ✅ **Modo Escuro/Claro** - Botão na barra superior
- ✅ **Navegação por Teclado** - Use TAB para navegar
- ✅ **Leitor de Tela** - NVDA, JAWS, VoiceOver
- ✅ **Contraste Alto** - Cores WCAG compatíveis
- ✅ **Fontes Legíveis** - Tamanhos e espaçamento adequados

---

**O VLibras torna o site de Tatiane Leão verdadeiramente inclusivo para toda a comunidade surda! 🤝**
