# Tatiane Leão - Intérprete de Libras 🤝

## 📋 Descrição

Site profissional landing page para Tatiane Leão, especializada em interpretação e educação em Libras (Língua Brasileira de Sinais). O site foi desenvolvido com foco em **acessibilidade**, **responsividade** e **inclusão**, com integração completa do **VLibras**.

## ✨ Características Principais

### 🎨 Design Moderno
- Cores inspiradas em Libras (azul, branco, tons pastéis)
- Interface intuitiva e moderna
- Animações suaves e transições fluidas
- Design responsivo (mobile-first)

### ♿ Acessibilidade com VLibras
- **VLibras Integrado**: Tradução automática para Libras em tempo real
- **Ícone de Acessibilidade**: Widget flutuante no canto da tela
- **Modo Escuro/Claro**: Toggle entre temas para conforto visual
- **HTML Semântico**: Preparado para leitores de tela
- **Navegação Intuitiva**: Menu fixo e smooth scroll
- **Fontes Legíveis**: Poppins, tamanhos generosos

### 🎥 Seção de Vídeos
- Até 6 vídeos do YouTube embutidos
- Layout responsivo em grade
- Proporção 16:9 automática

### 🚀 Performance
- Carregamento rápido
- Estrutura leve

## 📁 Estrutura do Projeto

```
tatiane-leao-site-v3/
├── index.html              # HTML com VLibras integrado
├── css/
│   └── styles.css          # CSS otimizado para VLibras
├── js/
│   └── script.js           # JavaScript
├── imagens/                # Pasta para imagens
└── README.md              # Este arquivo
```

## 🎥 O que é VLibras?

**VLibras** é uma tecnologia desenvolvida pelo **Governo Federal Brasileiro** que traduz conteúdo de texto e fala para a Língua Brasileira de Sinais (Libras) em tempo real, utilizando um avatar 3D.

### Como o VLibras Funciona no Site:

1. **Widget Flutuante**: Aparece automaticamente no canto inferior direito da tela
2. **Tradução Automática**: Traduz todo o conteúdo textual do site para Libras
3. **Avatar em Libras**: Exibe um intérprete virtual em tempo real
4. **Gratuito**: Serviço público disponibilizado pelo governo

### Como Usar o VLibras:

1. Procure o **ícone de acessibilidade** (V) no canto da tela
2. Clique para **ativar/desativar**
3. O avatar aparecerá traduzindo o conteúdo para Libras

## 🎯 Seções do Site

1. **Header Fixo**: Menu com navegação
2. **Hero**: Apresentação principal
3. **Experiência**: Dados profissionais
4. **Portfólio**: Galeria de trabalhos
5. **Vídeos**: Até 6 vídeos YouTube
6. **Sobre**: Informação completa (com menção ao VLibras)
7. **Serviços**: Detalhes dos serviços
8. **Contato**: Formulário e redes sociais
9. **Footer**: Links e copyright

## 🛠️ Como Usar

### Instalação
1. Extraia `tatiane-leao-site-v3.zip`
2. Abra `index.html` no navegador
3. O VLibras carregará automaticamente!

### Adicionar Vídeos YouTube

1. Copie o ID do vídeo: `https://youtube.com/watch?v=**AQUI_ESTA_O_ID**`
2. Edite `index.html` e localize `<!-- Seção Vídeos YouTube -->`
3. Substitua `ADICIONE_VIDEO_ID_1`, etc, pelos IDs reais

**Exemplo:**
```html
<iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ"></iframe>
```

### Adicionar Imagens

1. Coloque as imagens na pasta `imagens/`
2. Use os nomes:
   - `tatiane-leao-hero.jpg` (Hero)
   - `portfolio-evento.jpg` (Portfólio 1)
   - `portfolio-educacao.jpg` (Portfólio 2)
   - `portfolio-saude.jpg` (Portfólio 3)
   - `portfolio-treinamento.jpg` (Portfólio 4)
   - `portfolio-inclusao.jpg` (Portfólio 5)
   - `portfolio-consultoria.jpg` (Portfólio 6)

### Customizar Informações

Edite os dados em `index.html`:
- **Email**: tatiane.leao@gmail.com
- **Telefone**: (17) 98585-3652
- **Instagram**: @tatiane.leao.75
- **Facebook**: @tatiane.leao.75

### Cores e Tema

Edite em `css/styles.css`:
```css
:root {
    --primary-color: #0066cc;      /* Azul Libras */
    --accent-color: #00b8e6;       /* Ciano */
    /* ... mais cores ... */
}
```

## 🌐 Deploy Online

### GitHub Pages
1. Crie repositório público
2. Faça upload dos arquivos
3. Ative GitHub Pages

### Netlify
1. Acesse netlify.com
2. Drag & drop da pasta
3. Site publicado automaticamente!

### Servidor Web
1. Contrate hospedagem
2. FTP dos arquivos
3. Configure DNS

## ✅ Recursos de Acessibilidade

✅ **VLibras** - Tradução para Libras em tempo real  
✅ Modo escuro/claro  
✅ Menu responsivo  
✅ Navegação por teclado  
✅ ARIA labels  
✅ Contraste WCAG  
✅ Fontes legíveis  
✅ Smooth scroll  
✅ HTML semântico  
✅ Botão voltar ao topo  

## 📱 Compatibilidade

- ✅ Chrome/Edge
- ✅ Firefox
- ✅ Safari
- ✅ Opera
- ✅ Mobile (iOS/Android)

## 🔧 Tecnologias

- HTML5 semântico
- CSS3 responsivo
- JavaScript Vanilla
- VLibras (Governo Federal)
- Font Awesome
- Google Fonts

## 📞 Contato & Suporte

Para dúvidas sobre o site, entre em contato através das informações disponíveis nele mesmo.

Para informações sobre VLibras:
- Site Oficial: https://www.gov.br/acessibilidade/
- Documentação: https://vlibras.gov.br/

---

**Desenvolvido com ❤️ para promover acessibilidade e inclusão da comunidade surda.**

Versão 3.0 - Com VLibras integrado - 2024
